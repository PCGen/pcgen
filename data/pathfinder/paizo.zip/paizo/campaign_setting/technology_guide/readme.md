
# TODO: Heavy Weapon Harness Can be worn with other Armor

# Aggregate - This template needs thought to implement... it's taking another creature and imposing it on another. Might be best as a AI as a Creature, and then a aggregate "robot" as a Companion
